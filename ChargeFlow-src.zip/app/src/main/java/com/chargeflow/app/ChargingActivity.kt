package com.chargeflow.app

import android.app.Activity
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.sin

class ChargingActivity : Activity() {

    private data class Reading(
        val pct: Float,
        val watts: Double,
        val amps: Double,
        val volts: Double,
        val remainMs: Long,
        val charging: Boolean,
        val full: Boolean,
        val source: String
    )

    private val handler = Handler(Looper.getMainLooper())
    private val samples = ArrayDeque<Double>()
    private var demo = false

    private lateinit var chargeView: ChargeView
    private lateinit var pctText: TextView
    private lateinit var wattText: TextView
    private lateinit var timeText: TextView
    private lateinit var infoText: TextView

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!demo) finish()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        demo = intent.getBooleanExtra("demo", false)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        getSystemService(NotificationManager::class.java).cancel(ChargingService.ALERT_ID)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(16), dp(48), dp(16), dp(48))
            setOnClickListener { finish() }
        }
        chargeView = ChargeView(this)
        root.addView(chargeView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pctText = tv(56f, Color.WHITE, true)
        wattText = tv(28f, Color.parseColor("#00E5A0"), true)
        timeText = tv(20f, Color.WHITE, false)
        infoText = tv(14f, Color.GRAY, false)
        root.addView(pctText)
        root.addView(wattText)
        root.addView(timeText)
        root.addView(infoText)
        setContentView(root)
        try { hideBars() } catch (_: Throwable) {}

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(closer, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(closer, f)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun update() {
        val r = if (demo) demoReading() else readBattery()
        chargeView.percent = r.pct
        chargeView.animating = r.charging
        chargeView.color = if (r.watts >= 18) 0xFF22D3FF.toInt() else 0xFF00E5A0.toInt()
        wattText.setTextColor(chargeView.color)
        pctText.text = "${r.pct.toInt()}%"

        when {
            r.full -> {
                wattText.text = "Fully charged ✅"
                timeText.text = ""
            }
            !r.charging -> {
                wattText.text = "Charger nahi laga"
                timeText.text = ""
            }
            else -> {
                wattText.text = if (r.watts > 0.1) String.format("⚡ %.1f W", r.watts) else "⚡ measuring…"
                timeText.text = if (r.remainMs > 0) "Full in ${fmt(r.remainMs)}" else "Time calculate ho raha hai…"
            }
        }
        val speed = when {
            !r.charging -> ""
            r.watts >= 15 -> "Fast charging"
            r.watts >= 5 -> "Charging"
            else -> "Slow charging"
        }
        infoText.text = listOf(
            speed, r.source,
            if (r.volts > 0) String.format("%.2f V", r.volts) else "",
            if (r.amps > 0.01) String.format("%.2f A", r.amps) else ""
        ).filter { it.isNotEmpty() }.joinToString("  •  ")
    }

    private fun demoReading(): Reading {
        val t = System.currentTimeMillis() / 1000.0
        val w = 24.6 + sin(t) * 0.4
        return Reading(67f, w, w / 4.3, 4.3, 38 * 60_000L, true, false, "Demo")
    }

    private fun readBattery(): Reading {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = level * 100f / scale
        val mv = st?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val plugged = st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = plugged != 0
        val full = charging && (status == BatteryManager.BATTERY_STATUS_FULL || pct >= 100f)

        // Current (µA). Kuch phones mA me dete hain, sign alag hota hai -> abs
        val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        var ua = if (raw == Long.MIN_VALUE || raw == Int.MIN_VALUE.toLong()) 0.0 else abs(raw).toDouble()
        if (ua in 1.0..20000.0) ua *= 1000.0
        if (charging && ua > 0) {
            samples.addLast(ua)
            if (samples.size > 8) samples.removeFirst()
        }
        val avgUa = if (samples.isEmpty()) 0.0 else samples.average()
        val volts = mv / 1000.0
        val amps = avgUa / 1e6
        val watts = amps * volts

        // Time to full: pehle system ka estimate, warna khud ka
        var remain = -1L
        if (charging && Build.VERSION.SDK_INT >= 28) remain = bm.computeChargeTimeRemaining()
        if (charging && remain <= 0 && avgUa > 50_000) {
            val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toDouble() // µAh
            if (counter > 0 && pct > 0) {
                val fullCap = counter / (pct / 100.0)
                val knee = fullCap * 0.8 // 80% ke baad charging slow hoti hai
                val hours = if (counter < knee) {
                    (knee - counter) / avgUa + (fullCap - knee) / (avgUa * 0.45)
                } else {
                    (fullCap - counter) / (avgUa * 0.75)
                }
                remain = (hours * 3_600_000).toLong()
            }
        }

        val src = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> if (charging) "Dock" else ""
        }
        return Reading(pct, watts, amps, volts, remain, charging, full, src)
    }

    private fun fmt(ms: Long): String {
        val m = ceil(ms / 60000.0).toLong()
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }

    private fun tv(size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }
}

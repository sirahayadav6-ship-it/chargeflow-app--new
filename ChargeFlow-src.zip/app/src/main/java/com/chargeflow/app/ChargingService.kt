package com.chargeflow.app

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground service: charger lagte hi (ACTION_POWER_CONNECTED)
 * lock screen pe ChargingActivity dikhata hai.
 */
class ChargingService : Service() {

    companion object {
        const val CH_SERVICE = "cf_service"
        const val CH_ALERT = "cf_alert"
        const val SERVICE_ID = 1
        const val ALERT_ID = 2

        @Volatile
        var running = false
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_POWER_CONNECTED) {
                try {
                    showCharging()
                } catch (e: Throwable) {
                    note("Error: ${e.javaClass.simpleName} ${e.message}")
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Charging monitor", NotificationManager.IMPORTANCE_MIN)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Charging screen", NotificationManager.IMPORTANCE_HIGH)
        )

        val n = Notification.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("ChargeFlow chal raha hai")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(SERVICE_ID, n)
        }
        registerReceiver(receiver, IntentFilter(Intent.ACTION_POWER_CONNECTED))
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun note(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        getSharedPreferences("cf", MODE_PRIVATE).edit().putString("last", "$time  $msg").apply()
    }

    private fun showCharging() {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        val locked = km.isKeyguardLocked || !pm.isInteractive
        if (!locked) {
            note("Charger laga, par screen unlocked thi (sirf lock screen pe dikhata hai)")
            return
        }

        val intent = Intent(this, ChargingActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        val pi = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Charging")
            .setFullScreenIntent(pi, true)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_ID, n)

        try {
            startActivity(intent)
            note("Charger laga (locked) -> activity launch try ki")
        } catch (e: Throwable) {
            note("Charger laga (locked) -> launch fail: ${e.javaClass.simpleName}")
        }
    }
}
